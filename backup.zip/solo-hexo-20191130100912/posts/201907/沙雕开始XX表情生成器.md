title: 沙雕开始“XX”表情生成器
date: '2019-07-24 09:30:42'
updated: '2019-11-21 13:05:49'
tags: [菜鸡修炼手册, React, JavaScript]
permalink: /articles/2019/07/24/1563931842680.html
---
![](https://img.hacpai.com/bing/20190716.jpg?imageView2/1/w/960/h/540/interlace/1/q/100)

前段时间看到了几个表情，觉得不错
![9150e4e5gy1g52ffs90hdj203n01y0s0.jpg](https://img.hacpai.com/file/2019/07/9150e4e5gy1g52ffs90hdj203n01y0s0-1d320299.jpg)![9150e4e5ly1ftsrdtznmgj206o06oglj.jpg](https://img.hacpai.com/file/2019/07/9150e4e5ly1ftsrdtznmgj206o06oglj-a6b9898c.jpg)
然后就琢磨着做成动图，顺便可以自定义文字颜色，所以就有了下面这个仓库
https://github.com/csfwff/startdoing
效果看图，在线预览--> https://www.sszsj.top/pages/startdoing/index.html

![2](https://raw.githubusercontent.com/csfwff/startdoing/master/screenshot/1.gif)    ![3](https://raw.githubusercontent.com/csfwff/startdoing/master/screenshot/2.gif) 
![4](https://raw.githubusercontent.com/csfwff/startdoing/master/screenshot/3.gif)  ![5](https://raw.githubusercontent.com/csfwff/startdoing/master/screenshot/4.gif)

<img src="https://raw.githubusercontent.com/csfwff/startdoing/master/screenshot/Screenshot_20181226-154957.jpg" width="300"/>

由于是直接在动画过程中截图再拼成gif，所以有时效果不怎么好，多试几次就行了

